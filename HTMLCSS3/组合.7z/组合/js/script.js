$("#banner .title .text").animate({
    "width": "400px"
    , "opacity": "1"
}, 200, function () {
    $("html").css({
        "animation": "shark .3s"
    })
})